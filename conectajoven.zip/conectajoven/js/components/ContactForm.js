// ============================================
// CJ.ContactForm – formulario de contacto completo
//
// Este es el componente "orquestador": junta el estado
// del formulario, la validación en tiempo real y el envío,
// combinando los componentes reutilizables de esta carpeta
// (FormField, SelectField, TextareaField, CheckboxField,
// SubmitButton, AlertMessage).
//
// Se escribe con React.createElement (sin JSX) para no
// depender de Babel: funciona abriendo el index.html
// directamente con doble clic, sin necesitar servidor.
// ============================================
window.CJ = window.CJ || {};

CJ.ContactForm = function ContactForm() {
  var e = React.createElement;
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useCallback = React.useCallback;

  // --- Estado inicial de los campos del formulario ---
  var initialState = {
    nombre: '',
    email: '',
    telefono: '',
    carrera: '',
    servicio: '',
    mensaje: '',
    terminos: false,
  };

  var formDataState = useState(initialState);
  var formData = formDataState[0];
  var setFormData = formDataState[1];

  var errorsState = useState({});
  var errors = errorsState[0];
  var setErrors = errorsState[1];

  var touchedState = useState({});
  var touched = touchedState[0];
  var setTouched = touchedState[1];

  // status puede ser: "idle" | "loading" | "success" | "error"
  var statusState = useState('idle');
  var status = statusState[0];
  var setStatus = statusState[1];

  // Revalida todo el formulario cada vez que cambian los datos
  useEffect(function () {
    setErrors(CJ.validateForm(formData));
  }, [formData]);

  // Oculta el mensaje de éxito automáticamente después de 5 segundos
  useEffect(function () {
    if (status !== 'success') return undefined;
    var timer = setTimeout(function () { setStatus('idle'); }, 5000);
    return function () { clearTimeout(timer); };
  }, [status]);

  // Actualiza un campo del formulario
  var handleChange = useCallback(function (campo, valor) {
    setFormData(function (prev) {
      var copia = Object.assign({}, prev);
      copia[campo] = valor;
      return copia;
    });
  }, []);

  // Marca un campo como "tocado" (para recién mostrar su error)
  var handleBlur = useCallback(function (campo) {
    setTouched(function (prev) {
      var copia = Object.assign({}, prev);
      copia[campo] = true;
      return copia;
    });
  }, []);

  // Envío del formulario
  var handleSubmit = function (ev) {
    ev.preventDefault();

    var validacion = CJ.validateForm(formData);
    setErrors(validacion);
    setTouched({
      nombre: true, email: true, telefono: true,
      carrera: true, mensaje: true, terminos: true,
    });

    if (CJ.hasErrors(validacion)) {
      setStatus('error');
      var primerCampoInvalido = Object.keys(validacion).filter(function (c) {
        return validacion[c];
      })[0];
      var el = primerCampoInvalido && document.getElementById(primerCampoInvalido);
      if (el) el.focus();
      return;
    }

    setStatus('loading');

    // Simula el envío a un servidor (esta evidencia no tiene backend)
    setTimeout(function () {
      setStatus('success');
      setFormData(initialState);
      setTouched({});
    }, 1200);
  };

  var carreras = [
    { value: 'sistemas', label: 'Ingeniería de Sistemas' },
    { value: 'civil', label: 'Ingeniería Civil' },
    { value: 'admin', label: 'Administración de Empresas' },
    { value: 'derecho', label: 'Derecho' },
    { value: 'medicina', label: 'Medicina' },
    { value: 'psicologia', label: 'Psicología' },
    { value: 'otra', label: 'Otra carrera' },
  ];

  var servicios = [
    { value: 'vocacional', label: 'Orientación Vocacional' },
    { value: 'empleo', label: 'Bolsa de Empleo' },
    { value: 'beca', label: 'Becas y Financiamiento' },
    { value: 'cv', label: 'Taller CV y Entrevistas' },
    { value: 'mentor', label: 'Red de Mentores' },
  ];

  // --- Alerta de éxito o error (solo una a la vez) ---
  var alerta = null;
  if (status === 'success') {
    alerta = e(CJ.AlertMessage, {
      type: 'success',
      message: '¡Mensaje enviado! Un orientador se comunicará contigo pronto.',
      onClose: function () { setStatus('idle'); },
    });
  } else if (status === 'error' && CJ.hasErrors(errors)) {
    alerta = e(CJ.AlertMessage, {
      type: 'error',
      message: 'Revisa los campos marcados antes de continuar.',
      onClose: function () { setStatus('idle'); },
    });
  }

  // --- Fila 1: nombre + email ---
  var fila1 = e('div', { className: 'row g-3' },
    e('div', { className: 'col-md-6' },
      e(CJ.FormField, {
        id: 'nombre', label: 'Nombre completo', required: true,
        placeholder: 'Tu nombre completo',
        value: formData.nombre, error: errors.nombre, touched: touched.nombre,
        onChange: handleChange, onBlur: handleBlur,
      })
    ),
    e('div', { className: 'col-md-6' },
      e(CJ.FormField, {
        id: 'email', label: 'Correo electrónico', type: 'email', required: true,
        placeholder: 'tu@correo.com',
        value: formData.email, error: errors.email, touched: touched.email,
        onChange: handleChange, onBlur: handleBlur,
      })
    )
  );

  // --- Fila 2: teléfono + carrera ---
  var fila2 = e('div', { className: 'row g-3 mt-1' },
    e('div', { className: 'col-md-6' },
      e(CJ.FormField, {
        id: 'telefono', label: 'Teléfono', type: 'tel',
        placeholder: '+51 999 999 999',
        value: formData.telefono, error: errors.telefono, touched: touched.telefono,
        onChange: handleChange, onBlur: handleBlur,
      })
    ),
    e('div', { className: 'col-md-6' },
      e(CJ.SelectField, {
        id: 'carrera', label: 'Carrera universitaria', required: true,
        placeholder: 'Selecciona tu carrera', options: carreras,
        value: formData.carrera, error: errors.carrera, touched: touched.carrera,
        onChange: handleChange, onBlur: handleBlur,
      })
    )
  );

  // --- Servicio de interés ---
  var campoServicio = e('div', { className: 'mt-3' },
    e(CJ.SelectField, {
      id: 'servicio', label: 'Servicio de interés',
      placeholder: '¿Qué servicio te interesa?', options: servicios,
      value: formData.servicio, error: errors.servicio, touched: touched.servicio,
      onChange: handleChange, onBlur: handleBlur,
    })
  );

  // --- Mensaje ---
  var campoMensaje = e('div', { className: 'mt-3' },
    e(CJ.TextareaField, {
      id: 'mensaje', label: '¿En qué podemos ayudarte?', required: true,
      placeholder: 'Cuéntanos tu situación o consulta...', rows: 4, maxLength: 600,
      value: formData.mensaje, error: errors.mensaje, touched: touched.mensaje,
      onChange: handleChange, onBlur: handleBlur,
    })
  );

  // --- Términos y condiciones ---
  var campoTerminos = e('div', { className: 'mt-3' },
    e(CJ.CheckboxField, {
      id: 'terminos',
      label: 'Acepto los términos y condiciones de ConectaJoven',
      checked: formData.terminos, error: errors.terminos, touched: touched.terminos,
      onChange: handleChange, onBlur: handleBlur,
    })
  );

  var boton = e(CJ.SubmitButton, { loading: status === 'loading' });

  var formulario = e(
    'form',
    { id: 'contacto-form', noValidate: true, onSubmit: handleSubmit },
    fila1, fila2, campoServicio, campoMensaje, campoTerminos, boton
  );

  var titulo = e('h3', { className: 'mb-4', style: { fontSize: '1.2rem' } }, 'Envíanos tu consulta');

  return e('div', { className: 'form-wrapper' }, titulo, alerta, formulario);
};
