// ============================================
// CJ.FormField – campo de texto reutilizable
// Sirve para inputs type="text" | "email" | "tel"
//
// Se escribe con React.createElement (sin JSX) para
// no depender de Babel: así el archivo funciona igual
// abriendo el index.html directamente (doble clic) o
// desde un servidor local.
//
// Props que recibe:
//   id          -> id/name del campo (string)
//   label       -> texto de la etiqueta (string)
//   type        -> "text" | "email" | "tel" (opcional)
//   value       -> valor actual del campo (string)
//   placeholder -> texto de ayuda (string)
//   required    -> si es obligatorio (boolean)
//   error       -> mensaje de error a mostrar (string)
//   touched     -> si el usuario ya interactuó con el campo (boolean)
//   onChange    -> función (id, valor) que actualiza el estado del padre
//   onBlur      -> función (id) que marca el campo como "touched"
// ============================================
window.CJ = window.CJ || {};

CJ.FormField = function FormField(props) {
  var e = React.createElement;
  var id = props.id;
  var label = props.label;
  var type = props.type || 'text';
  var value = props.value;
  var placeholder = props.placeholder;
  var required = props.required || false;
  var error = props.error;
  var touched = props.touched;
  var onChange = props.onChange;
  var onBlur = props.onBlur;

  var showError = Boolean(touched && error);
  var errorId = id + '-error';

  // Etiqueta del campo (con asterisco si es obligatorio)
  var etiqueta = e(
    'label',
    { htmlFor: id, className: 'form-label' },
    label,
    required ? e('span', { 'aria-hidden': 'true' }, ' *') : null
  );

  // Input controlado: su valor siempre viene del estado de React
  var input = e('input', {
    type: type,
    id: id,
    name: id,
    className: 'form-control' + (showError ? ' is-invalid' : ''),
    placeholder: placeholder,
    value: value,
    onChange: function (ev) { onChange(id, ev.target.value); },
    onBlur: function () { onBlur(id); },
    'aria-invalid': showError,
    'aria-describedby': showError ? errorId : undefined,
  });

  // Mensaje de error (solo se muestra si el campo fue tocado y tiene error)
  var mensajeError = showError
    ? e('span', { id: errorId, className: 'cj-error-text', role: 'alert' }, error)
    : null;

  return e('div', null, etiqueta, input, mensajeError);
};
