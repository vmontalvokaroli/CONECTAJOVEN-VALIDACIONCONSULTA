// ============================================
// CJ.AlertMessage – alerta reutilizable (éxito / error)
// Usada por ContactForm para avisar si el envío
// fue exitoso o si hay campos por corregir.
//
// Props: type ("success" | "error"), message, onClose
// ============================================
window.CJ = window.CJ || {};

CJ.AlertMessage = function AlertMessage(props) {
  var e = React.createElement;
  var type = props.type || 'success';
  var message = props.message;
  var onClose = props.onClose;

  var clase = type === 'success' ? 'cj-alert-success' : 'cj-alert-error';
  var icono = type === 'success' ? '✅' : '⚠️';

  var texto = e('span', null, icono + ' ' + message);

  var botonCerrar = e(
    'button',
    {
      type: 'button',
      className: 'cj-alert-close',
      'aria-label': 'Cerrar mensaje',
      onClick: onClose,
    },
    '✕'
  );

  return e('div', { className: 'cj-alert ' + clase, role: 'status' }, texto, botonCerrar);
};
