// ============================================
// CJ.SubmitButton – botón de envío reutilizable
// Muestra un spinner y cambia de texto mientras
// el formulario se está "enviando" (estado loading).
//
// Props: loading (boolean), children (texto del botón)
// ============================================
window.CJ = window.CJ || {};

CJ.SubmitButton = function SubmitButton(props) {
  var e = React.createElement;
  var loading = props.loading;
  var texto = loading ? 'Enviando…' : (props.children || 'Enviar consulta');

  var spinner = loading ? e('span', { className: 'cj-spinner', 'aria-hidden': 'true' }) : null;

  return e(
    'button',
    { type: 'submit', className: 'btn btn-cj w-100 mt-4', disabled: loading },
    spinner,
    texto
  );
};
