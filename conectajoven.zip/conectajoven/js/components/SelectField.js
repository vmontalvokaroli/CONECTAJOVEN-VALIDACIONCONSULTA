// ============================================
// CJ.SelectField – select (lista desplegable) reutilizable
//
// Props:
//   id, label, value, placeholder, options ([{value,label}]),
//   required, error, touched, onChange, onBlur
// ============================================
window.CJ = window.CJ || {};

CJ.SelectField = function SelectField(props) {
  var e = React.createElement;
  var id = props.id;
  var label = props.label;
  var value = props.value;
  var placeholder = props.placeholder;
  var options = props.options || [];
  var required = props.required || false;
  var error = props.error;
  var touched = props.touched;
  var onChange = props.onChange;
  var onBlur = props.onBlur;

  var showError = Boolean(touched && error);
  var errorId = id + '-error';

  var etiqueta = e(
    'label',
    { htmlFor: id, className: 'form-label' },
    label,
    required ? e('span', { 'aria-hidden': 'true' }, ' *') : null
  );

  // Construye la lista de <option> a partir del arreglo "options"
  var opciones = [e('option', { key: 'placeholder', value: '' }, placeholder)];
  options.forEach(function (opt) {
    opciones.push(e('option', { key: opt.value, value: opt.value }, opt.label));
  });

  var select = e(
    'select',
    {
      id: id,
      name: id,
      className: 'form-select' + (showError ? ' is-invalid' : ''),
      value: value,
      onChange: function (ev) { onChange(id, ev.target.value); },
      onBlur: function () { onBlur(id); },
      'aria-invalid': showError,
      'aria-describedby': showError ? errorId : undefined,
    },
    opciones
  );

  var mensajeError = showError
    ? e('span', { id: errorId, className: 'cj-error-text', role: 'alert' }, error)
    : null;

  return e('div', null, etiqueta, select, mensajeError);
};
