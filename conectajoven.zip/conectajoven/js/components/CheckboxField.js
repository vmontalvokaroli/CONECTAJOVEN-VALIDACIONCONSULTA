// ============================================
// CJ.CheckboxField – casilla de verificación reutilizable
//
// Props: id, label, checked, error, touched, onChange, onBlur
// ============================================
window.CJ = window.CJ || {};

CJ.CheckboxField = function CheckboxField(props) {
  var e = React.createElement;
  var id = props.id;
  var label = props.label;
  var checked = props.checked;
  var error = props.error;
  var touched = props.touched;
  var onChange = props.onChange;
  var onBlur = props.onBlur;

  var showError = Boolean(touched && error);
  var errorId = id + '-error';

  var input = e('input', {
    className: 'form-check-input' + (showError ? ' is-invalid' : ''),
    type: 'checkbox',
    id: id,
    name: id,
    checked: checked,
    onChange: function (ev) { onChange(id, ev.target.checked); },
    onBlur: function () { onBlur(id); },
    'aria-invalid': showError,
    'aria-describedby': showError ? errorId : undefined,
  });

  var etiqueta = e(
    'label',
    {
      className: 'form-check-label',
      htmlFor: id,
      style: { fontSize: '0.85rem', color: 'var(--cj-muted)' },
    },
    label
  );

  var casilla = e('div', { className: 'form-check' }, input, etiqueta);

  var mensajeError = showError
    ? e('span', { id: errorId, className: 'cj-error-text', role: 'alert' }, error)
    : null;

  return e('div', null, casilla, mensajeError);
};
