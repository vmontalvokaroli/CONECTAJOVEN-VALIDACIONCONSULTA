// ============================================
// CJ.TextareaField – textarea reutilizable
// Incluye un contador de caracteres dinámico
//
// Props:
//   id, label, value, placeholder, rows, maxLength,
//   required, error, touched, onChange, onBlur
// ============================================
window.CJ = window.CJ || {};

CJ.TextareaField = function TextareaField(props) {
  var e = React.createElement;
  var id = props.id;
  var label = props.label;
  var value = props.value;
  var placeholder = props.placeholder;
  var rows = props.rows || 4;
  var maxLength = props.maxLength;
  var required = props.required || false;
  var error = props.error;
  var touched = props.touched;
  var onChange = props.onChange;
  var onBlur = props.onBlur;

  var showError = Boolean(touched && error);
  var errorId = id + '-error';

  var etiqueta = e(
    'label',
    { htmlFor: id, className: 'form-label' },
    label,
    required ? e('span', { 'aria-hidden': 'true' }, ' *') : null
  );

  var textarea = e('textarea', {
    id: id,
    name: id,
    rows: rows,
    maxLength: maxLength,
    className: 'form-control' + (showError ? ' is-invalid' : ''),
    placeholder: placeholder,
    value: value,
    onChange: function (ev) { onChange(id, ev.target.value); },
    onBlur: function () { onBlur(id); },
    'aria-invalid': showError,
    'aria-describedby': showError ? errorId : undefined,
  });

  // Contador "caracteres escritos / máximo permitido"
  var contador = maxLength
    ? e('span', { className: 'cj-char-count' }, value.length + ' / ' + maxLength)
    : null;

  var mensajeError = showError
    ? e('span', { id: errorId, className: 'cj-error-text', role: 'alert' }, error)
    : null;

  return e('div', null, etiqueta, textarea, contador, mensajeError);
};
