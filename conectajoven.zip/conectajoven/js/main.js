// ============================================
// ConectaJoven – main.js
// Interactividad general del sitio con JavaScript
// nativo (eventos del DOM, manipulación dinámica).
// El formulario de contacto se maneja aparte con
// componentes React (ver js/components y js/app.js).
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  initNavbarScroll();
  initMobileMenuAutoClose();
  initActiveNavLink();
  initRevealOnScroll();
});

// --- 1. Cambia el fondo del navbar al hacer scroll (evento "scroll") ---
function initNavbarScroll() {
  const navbar = document.querySelector('.navbar-custom');
  if (!navbar) return;

  const toggleScrolled = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 40);
  };

  toggleScrolled();
  window.addEventListener('scroll', toggleScrolled, { passive: true });
}

// --- 2. Cierra el menú móvil al hacer click en un enlace (evento "click") ---
function initMobileMenuAutoClose() {
  const menu = document.getElementById('navbarMenu');
  if (!menu) return;

  const links = menu.querySelectorAll('.nav-link');
  links.forEach((link) => {
    link.addEventListener('click', () => {
      if (menu.classList.contains('show') && window.bootstrap) {
        const collapse = window.bootstrap.Collapse.getOrCreateInstance(menu);
        collapse.hide();
      }
    });
  });
}

// --- 3. Resalta en el menú la sección visible en pantalla ---
function initActiveNavLink() {
  const sections = document.querySelectorAll('main section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  if (!sections.length || !navLinks.length || !('IntersectionObserver' in window)) return;

  const linkFor = (id) => document.querySelector(`.nav-link[href="#${id}"]`);

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const link = linkFor(entry.target.id);
        if (!link) return;
        navLinks.forEach((l) => l.classList.remove('active'));
        link.classList.add('active');
      });
    },
    { rootMargin: '-45% 0px -50% 0px', threshold: 0 }
  );

  sections.forEach((section) => observer.observe(section));
}

// --- 4. Animación de aparición al hacer scroll (dotar de dinamismo) ---
function initRevealOnScroll() {
  const elements = document.querySelectorAll('.cj-card, .sobre-mini-card, .stat-card');
  if (!elements.length) return;

  elements.forEach((el) => el.classList.add('reveal-on-scroll'));

  if (!('IntersectionObserver' in window)) {
    elements.forEach((el) => el.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  elements.forEach((el, index) => {
    el.style.transitionDelay = `${(index % 6) * 60}ms`;
    observer.observe(el);
  });
}
