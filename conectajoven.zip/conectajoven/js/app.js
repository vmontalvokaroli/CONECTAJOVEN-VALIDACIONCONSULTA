// ============================================
// ConectaJoven – app.js
// Punto de entrada de React: monta el módulo de
// formularios interactivos dentro de <div id="contacto-form-root">
// ============================================
(function mountContactForm() {
  var root = document.getElementById('contacto-form-root');

  if (!root || !window.React || !window.ReactDOM || !window.CJ || !CJ.ContactForm) {
    console.error('No se pudo montar el formulario de contacto: faltan dependencias.');
    return;
  }

  var e = React.createElement;
  ReactDOM.createRoot(root).render(e(CJ.ContactForm));
})();
