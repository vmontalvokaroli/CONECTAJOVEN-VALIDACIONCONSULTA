// ============================================
// ConectaJoven – validators.js
// Funciones puras y reutilizables para validar
// los campos del formulario de contacto.
// No dependen de React: pueden reutilizarse en
// cualquier parte del sitio.
// ============================================

window.CJ = window.CJ || {};

// --- Expresiones regulares reutilizables ---
CJ.patterns = {
  nombre: /^[A-Za-zÁÉÍÓÚÜáéíóúüÑñ\s'-]{3,60}$/,
  email: /^[\w.+-]+@[\w-]+\.[A-Za-z]{2,}$/,
  telefonoPE: /^(\+51\s?)?9\d{8}$/,
};

// --- Validadores individuales por campo ---
CJ.validators = {
  nombre(valor) {
    const v = (valor || '').trim();
    if (!v) return 'El nombre es obligatorio.';
    if (!CJ.patterns.nombre.test(v)) {
      return 'Ingresa un nombre válido (solo letras, mínimo 3 caracteres).';
    }
    return '';
  },

  email(valor) {
    const v = (valor || '').trim();
    if (!v) return 'El correo electrónico es obligatorio.';
    if (!CJ.patterns.email.test(v)) return 'Ingresa un correo electrónico válido.';
    return '';
  },

  telefono(valor) {
    const v = (valor || '').trim();
    if (!v) return ''; // campo opcional
    if (!CJ.patterns.telefonoPE.test(v)) {
      return 'Ingresa un celular peruano válido (9 dígitos, ej. 987654321).';
    }
    return '';
  },

  carrera(valor) {
    if (!valor) return 'Selecciona tu carrera universitaria.';
    return '';
  },

  mensaje(valor) {
    const v = (valor || '').trim();
    if (!v) return 'Cuéntanos brevemente tu consulta.';
    if (v.length < 10) return 'Tu mensaje debe tener al menos 10 caracteres.';
    if (v.length > 600) return 'Tu mensaje no debe superar los 600 caracteres.';
    return '';
  },

  terminos(valor) {
    if (!valor) return 'Debes aceptar los términos y condiciones.';
    return '';
  },
};

// --- Valida un objeto formData completo ---
CJ.validateForm = function validateForm(formData) {
  return {
    nombre: CJ.validators.nombre(formData.nombre),
    email: CJ.validators.email(formData.email),
    telefono: CJ.validators.telefono(formData.telefono),
    carrera: CJ.validators.carrera(formData.carrera),
    mensaje: CJ.validators.mensaje(formData.mensaje),
    terminos: CJ.validators.terminos(formData.terminos),
  };
};

// --- Indica si un objeto de errores tiene algún mensaje activo ---
CJ.hasErrors = function hasErrors(errors) {
  return Object.keys(errors).some((campo) => Boolean(errors[campo]));
};
